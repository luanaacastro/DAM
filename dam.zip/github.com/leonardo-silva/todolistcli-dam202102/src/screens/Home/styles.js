import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#121015'
    },
    text: {
        fontSize: 30,
        color: 'white',
        margin: 20,
        padding: 100,
        flex: 1,
       justifyContent: 'center',
       alignSelf : "center"
          
        
    },
   
  
    buttonTask: {
        backgroundColor: '#1F1E25',
        padding: 15,
        borderRadius: 22,
        marginHorizontal: 20,
        marginBottom: 10
    },
    textTask: {
        color: 'white',
        fontSize: 20
    }
})